# Native Release (Cython Compiled)

This release contains **natively compiled** Python code that cannot be decompiled.

## Requirements

- Python 3.10+
- Dependencies: `pip install -r requirements.txt`

## Usage

```bash
cd release_native
export PYTHONPATH="$(pwd):$PYTHONPATH"

# Train long-CP specialist
./bin/train_longcp_specialist.sh

# Train wide specialist  
./bin/train_wide_specialist.sh
```

## Contents

- `bin/` - Shell scripts to run experiments
- `scheduler/` - Compiled native modules (.so files)
- `scripts/` - Compiled evaluation scripts (.so files)
- `data/` - Configuration files
- `runs/datasets/` - Seed files for reproducibility

## Note

The `.so` files are platform-specific (macOS/Linux). 
This release was built for: $(uname -s) $(uname -m)
