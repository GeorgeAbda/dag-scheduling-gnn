# DAG-Aware Energy Scheduling - Experiment Scripts

Executable scripts for reproducing experiments from:
**"On the Role of DAG Structure in Energy-Aware Scheduling with Deep Reinforcement Learning"**

## Requirements

```bash
pip install -r requirements.txt
```

## Usage

```bash
# Train Long-CP specialist
./bin/train_longcp_specialist.sh

# Train Wide specialist  
./bin/train_wide_specialist.sh

# Evaluate heuristics
./bin/eval_heuristics.sh

# Evaluate agents
./bin/eval_agents_all_cases.sh
```

## Configuration

Set environment variables to customize:

```bash
HOST_SPECS_PATH=data/host_specs_homoPower.json ./bin/train_longcp_specialist.sh
SEED=42 TOTAL_TIMESTEPS=1000000 ./bin/train_wide_specialist.sh
```

## Host Specification Cases

| Case | File | Description |
|------|------|-------------|
| AL | `data/host_specs.json` | Default heterogeneous |
| HP | `data/host_specs_homoPower.json` | Homogeneous power |
| HS | `data/host_specs_homospeed.json` | Homogeneous speed |
